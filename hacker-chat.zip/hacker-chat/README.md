# SECURE TERMINAL — 部署說明

## 檔案結構
```
hacker-chat/
├── server.js        ← Node.js WebSocket + HTTP server
├── package.json     ← 依賴設定
└── public/
    └── index.html   ← 前端網頁
```

---

## 部署到 Railway（免費）

### 步驟 1：上傳到 GitHub
1. 去 github.com 建立新 repository（名字隨便，例如 `hacker-chat`）
2. 把這三個檔案上傳進去（直接拖曳到網頁即可）

### 步驟 2：部署到 Railway
1. 去 railway.app，用 GitHub 帳號登入
2. 點 **New Project** → **Deploy from GitHub repo**
3. 選你剛建立的 repository
4. Railway 會自動偵測並部署（約 1 分鐘）

### 步驟 3：取得網址
1. 部署完成後點 **Settings** → **Domains**
2. 點 **Generate Domain**，會得到類似：
   `https://hacker-chat-production.up.railway.app`
3. 把這個網址傳給朋友，直接用瀏覽器打開就能用

---

## 預設帳號

| 帳號   | 密碼      | 角色  | 顏色 |
|--------|-----------|-------|------|
| admin  | admin123  | ROOT  | 綠色 |
| ghost  | ghost999  | GHOST | 紅色 |
| cipher | cipher42  | USER  | 藍色 |
| neo    | matrix01  | USER  | 黃色 |

要新增帳號：編輯 `server.js` 第 10-15 行的 `USERS` 物件。

---

## 本機測試（可選）

```bash
npm install
npm start
# 打開 http://localhost:8080
```
